
#Specify input data directory
DataFolder="data"

#Specify name of data file (.csv)
DataFile='bond_disbond_per_for_cnn'

#Specify output directory
OutputFolder="output_per"

# Temporary directory
TempPath='/temp/temp_per_mlp'

#Specify MLP activation function layer 1 (e.g. Activation1="relu,tanh")
Activation1="relu"

#Specify MLP activation function layer 2
Activation2=${Activation1}

#Specify number of hidden nodes in MLP layer 1
HiddenNodes1="16384,8192,4096,2048,1024,512,256"

#Specify number of hidden nodes in MLP layer 2
HiddenNodes2=${HiddenNodes1}

# Scale of normalization
Scale="1.0"

# Learning Rate
Rate="0.0001,0.00001"

# Number of epochs
Epoch=500

# Batch size
Batch=50



Py=$(which python)

echo "###########################################################################"
echo "MLP2 for Classification of Periodograms"
echo "Input Data Folder: ${DataFolder}"
echo "Input Data File: ${DataFile}"
echo "Output Folder: ${OutputFolder}"
echo "MLP Activations 1: ${Activation1}"
echo "MLP Activations 2: ${Activation2}"
echo "MLP Hidden Nodes 1: ${HiddenNodes1}"
echo "MLP Hidden Nodes 2: ${HiddenNodes2}"
echo "Scale: ${Scale}"
echo "Learning Rate: ${Rate}"
echo "Number of Epochs: ${Epoch}"
echo "Batch Size: ${Batch}"
echo "Using Python at: ${Py}"
echo "###########################################################################"


time python src/analytics/api_per_mlp2_cv.py $DataFolder $DataFile $OutputFolder ${Activation1} ${Activation2} ${HiddenNodes1} ${HiddenNodes2} $Scale $Rate $Epoch $Batch $TempPath


