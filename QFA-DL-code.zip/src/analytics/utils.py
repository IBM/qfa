import os
import errno
import logging


def create_dir_if_not_exist(dirname):

    if not os.path.exists(dirname):
        try:
            os.makedirs(dirname)
        except OSError as exc: # Guard against race condition
            if exc.errno == errno.EEXIST and os.path.isdir(dirname):
                pass
            else:
                raise
        logging.info('Created directory %s', dirname)
    else:
        logging.info('Directory %s already exists', dirname)
        
    return 1
