# coding: utf-8
import numpy as np
import pandas as pd
import csv
import time 

import os
import sys
import argparse

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from analytics.deep_learning_modules import cnn22_2d_cv_trial
from analytics.utils import create_dir_if_not_exist


def main(argv):
    #%%%%%%%%%%
    # Parse arguments
    ##########
    parser = argparse.ArgumentParser(description = "CNN22 API for Quantile Periodograms")
    parser.add_argument("DataPath", help="Path to data file",default="../data")
    parser.add_argument("DataFile", help="Name of data file",default="bond_disbond_stqfa_for_cnn_15x23x29")
    parser.add_argument("Windows", help="Number of moving windows",default=29)
    parser.add_argument("Quantiles", help="Number of quantiles",default=23)
    parser.add_argument("OutputPath", help="Path to output files", default="output_stqfa")
    parser.add_argument("ActivationC1", help="Convolution Layer 1 Activations", default="relu")
    parser.add_argument("ActivationC2", help="Convolution Layer 2 Activations", default="relu")
    parser.add_argument("FeatureMap1", help="Number of Feature Maps Layer 1", default=128)
    parser.add_argument("FeatureMap2", help="Number of Feature Maps Layer 2", default=128)
    parser.add_argument("FilterSize1", help="Size of Filter Layer 1", default=5)
    parser.add_argument("FilterSize2", help="Size of Filter Layer 2", default=5)
    parser.add_argument("Activation1", help="MLP Layer 1 Activations", default="relu")
    parser.add_argument("Activation2", help="MLP Layer 2 Activations", default="relu")
    parser.add_argument("HiddenNodes1", help="Layer 1 Hidden Nodes", default="128")
    parser.add_argument("HiddenNodes2", help="Layer 2 Hidden Nodes", default="128")
    parser.add_argument("Scale", help="Scale of Normalization", default="1.0")
    parser.add_argument("Rate", help="Learning Rate", default="0.0001")
    parser.add_argument("Epoch", help="Number of epochs", default=100)
    parser.add_argument("Batch", help="Batch Size", default=50)
    parser.add_argument("TempPath", help="Path to temporary files", default="temp_qper")
	   
    args = vars(parser.parse_args(argv))
	
    # specify input, output and temporary directories
    data_dir = args["DataPath"]
    output_dir = args["OutputPath"]
    # specify data file
    data_file = args["DataFile"]
    # specify number of moving windows
    nt = int(args["Windows"])
    # specify number of quantiles
    nr = int(args["Quantiles"])
    # convolution layer activation functions
    c1s = str(args['ActivationC1'])
    c2s = str(args['ActivationC2'])
    # convolution layer numbers of feature maps
    f1s = str(args['FeatureMap1'])
    f2s = str(args['FeatureMap2'])
    # convolution layer filter sizes
    k1s = str(args['FilterSize1'])
    k2s = str(args['FilterSize2'])
    # mlp layer activation functions
    a1s = str(args['Activation1'])
    a2s = str(args['Activation2'])
    # mlp layer numbers of hidden nodes
    h1s = str(args['HiddenNodes1'])
    h2s = str(args['HiddenNodes2'])
    # scale of normalization
    scales = str(args['Scale'])
    # learning rate
    lrs = str(args['Rate'])
    # number of epochs
    epochs = int(args['Epoch'])
    # batch size
    batch_size = int(args['Batch'])
    # temp dir
    temp_dir = args['TempPath']
	
    c1s = c1s.split(',')
    c2s = c2s.split(',')
    f1s = list(map(int,f1s.split(',')))
    f2s = list(map(int,f2s.split(',')))
    k1s = list(map(int,k1s.split(',')))
    k2s = list(map(int,k2s.split(',')))
	
    a1s = a1s.split(',')
    a2s = a2s.split(',')
    h1s = list(map(int,h1s.split(',')))
    h2s = list(map(int,h2s.split(',')))
    
    scales = list(map(float,scales.split(',')))
    lrs = list(map(float,lrs.split(',')))

    # import data
    data = pd.read_csv(data_dir + '/' + data_file + '.csv')
	
    # extract folds, labels, and x
    folds = data['fold']
    labels = data['class']
    x = data[data.columns[2:]]

    # convert x to 2-d array (ns = number of cases; nr = number of quantiles; nc = number of frequencies)
    x = np.array(x)
    ns = x.shape[0]
    nc = int(x.shape[1]/nr/nt)
	
    if nc * nr * nt == x.shape[1]:
       pass
    else:
       print("Wrong Number of Quantiles",nr)
       return
	
    # self-standardization
    ##for i in range(ns):  x[i,] = x[i,]/np.std(x[i,])

    # reshape x for modeling (2d tensor, channel = moving windows)
    x = x.reshape( [-1, nr, nc, nt])
	
    # define y from labels for modeling
    y = np.ones([ns,2])
    for i in range(ns):
        if labels[i] == 1:
            y[i] = [1,0]
        else:
            y[i] = [0,1]

    # set output_dir
    create_dir_if_not_exist(output_dir)
    output_file = output_dir + '/' + data_file + '_stqper_cnn22_2d'

    # set temp_dir	
    create_dir_if_not_exist(temp_dir)
		
    # run cv of cnn22 model
    start_time_complete = time.time()
    cnn22_2d_cv_trial(output_file,x,y,folds,c1s,c2s,f1s,f2s,k1s,k2s,a1s,a2s,h1s,h2s,scales,lrs,epochs,batch_size,temp_dir)
    print("Total time =",time.strftime("%Hh%Mm%Ss", time.gmtime(time.time() - start_time_complete)))	

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
	



