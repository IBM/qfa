
import tensorflow as tf
from tensorflow.keras import layers
from tensorflow.keras import Input
from tensorflow.keras.layers import Lambda
from tensorflow.keras import optimizers
from tensorflow.keras import Model
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.regularizers import l2
from tensorflow.compat.v1 import ConfigProto
from tensorflow.compat.v1 import InteractiveSession
from keras import backend as K

import numpy as np
import pandas as pd
import csv
import time 
import os
import sys


def spread(x):
    return max(x)-min(x)

def my_init(activ,seed=None):
    init = tf.keras.initializers.glorot_normal(seed=seed)
    ##if activ in ['relu','linear']:		
    ##    init = tf.keras.initializers.VarianceScaling(seed=seed)
    ##else:
    ##    init = tf.keras.initializers.glorot_normal(seed=seed)
    return init

def cnn2mlp_input_size(nr,nc,f,pooling=2):
# dim of input to MLP from 2-layer CNN
# nr x nc = dim of input image
    if nr > 1:
        nr2 = np.int(np.floor(np.floor(nr/pooling)/pooling))
    else:
        nr2 = 1
    nc2 = np.int(np.floor(np.floor(nc/pooling)/pooling))
    n = nr2 * nc2 * f[1]
    return n

def mlp2_1d_cv(x,y,folds,h=[512,512],activm=['relu','relu'],scale=1.0,lr=1e-4,epochs=100,batch_size=50,temp_dir='temp',seed=1000):
    padding = 'same'
    nc = x.shape[1]
    nb = x.shape[2]
    nfolds = max(folds)
    accuracy_train = np.ones(nfolds)
    accuracy_test = np.ones(nfolds)
    maxepoch = np.ones(nfolds)
    for i in range(nfolds):
        test_sel = (folds == i+1)
        train_sel = ~(folds == i+1)
        x_train = x[train_sel,]
        y_train = y[train_sel,]
        x_test = x[test_sel,]
        y_test = y[test_sel,]
        np.random.seed(seed)
        idx = np.random.permutation(x_train.shape[0]) ## shuffle training data
        x_train = x_train[idx,]
        y_train = y_train[idx,]
        # data scaling
        x_train = scale * x_train
        x_test = scale * x_test
        ##print('Fold',i+1)
        K.clear_session()
        tf.compat.v1.random.set_random_seed(seed)
        inp = Input(shape=(nc,nb),dtype = 'float32')
        flat = layers.Flatten()(inp)
        ##flat = layers.Dropout(0.5)(flat)
        fc1 = layers.Dense(h[0],activation = activm[0],kernel_initializer=my_init(activm[0],seed))(flat)
        ##fc1 = layers.Dropout(0.2)(fc1)
        fc2 = layers.Dense(h[1],activation = activm[1],kernel_initializer=my_init(activm[1]))(fc1)
        ##fc2 = layers.Dropout(0.2)(fc2)
        out = layers.Dense(2,activation = 'sigmoid',kernel_initializer=my_init('sigmoid'))(fc2)
        # early stopping
        callback_earlyStop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5)
        model = Model(inp,out)
        ##model.summary()
        model.compile(loss = 'categorical_crossentropy', optimizer = optimizers.Adam(learning_rate = lr), metrics = ['acc'])
        if not os.path.exists(temp_dir): os.makedirs(temp_dir)
        filepath = temp_dir+'/mlp_1d_'+str(i)+'.h5'
        if os.path.exists(filepath): os.remove(filepath)
        callbacks_list = [tf.keras.callbacks.ModelCheckpoint(filepath=filepath,monitor='val_loss',save_best_only=True), 
            tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=2),callback_earlyStop]
        history = model.fit(x_train,y_train,validation_split=0.2,epochs=epochs,
            batch_size=batch_size,callbacks=callbacks_list, verbose=0)
        ytrain_pred = model.predict([x_train])
        ytest_pred = model.predict([x_test])
        ytr_pred0 = ytrain_pred[:,0] > ytrain_pred[:,1]
        yte_pred0 = ytest_pred[:,0] > ytest_pred[:,1]
        accuracy_train[i] = 100*(1.0 - np.mean(ytr_pred0 == y_train[:,1]))
        accuracy_test[i] = 100*(1.0 - np.mean(yte_pred0 == y_test[:,1]))
        maxepoch[i] = len(history.history['acc'])
    nparams = model.count_params()
    return accuracy_train, accuracy_test, nparams, maxepoch, model, history, 


def mlp2_1d_cv_trial(output_file,x,y,folds,a1s,a2s,h1s,h2s,scales=[1.0],lrs=[1e-4],epochs=100,batch_size=50,temp_dir='temp_mlp2_1d'):
    # function that compute cv results of mlp2 model
    activms = [[a1,a2] for a1 in a1s for a2 in a2s if a1==a2]
    hs = [[h1,h2] for h1 in h1s for h2 in h2s if h1 >= h2]
    params = [[h,scale,lr] for h in hs for scale in scales for lr in lrs]
    for activm in activms:
        start_time = time.time()
        print('activm:',activm)
        acc_train_mean = list()
        acc_train_min = list()
        acc_train_max = list()
        acc_train_spread = list()
        acc_test_mean = list()
        acc_test_min = list()
        acc_test_max = list()
        acc_test_spread = list()
        epoch_mean = list()
        epoch_min = list()
        epoch_max = list()
        nparams = list()
        hh = list()
        ss = list()
        rr = list()
        dur = list()
        for par in params:
            start_time2 = time.time()
            h = par[0]
            scale = par[1]
            lr = par[2]
            print('h =',h,' scale =',scale,' lr = ',lr)
            sys.stdout.flush()
            accuracy_train,accuracy_test,npar,maxepoch,model,history = mlp2_1d_cv(x,y,folds,h=h,activm=activm,\
                       scale=scale,lr=lr,epochs=epochs,batch_size=batch_size,temp_dir=temp_dir)
            acc_train_mean.append(np.round(np.mean(accuracy_train),2))
            acc_train_min.append(np.round(np.min(accuracy_train),2))
            acc_train_max.append(np.round(np.max(accuracy_train),2))
            acc_train_spread.append(np.round(spread(accuracy_train),2))
            acc_test_mean.append(np.round(np.mean(accuracy_test),2))
            acc_test_min.append(np.round(np.min(accuracy_test),2))
            acc_test_max.append(np.round(np.max(accuracy_test),2))
            acc_test_spread.append(np.round(spread(accuracy_test),2))
            epoch_mean.append(np.round(np.mean(maxepoch),2))
            epoch_min.append(np.round(np.min(maxepoch)))
            epoch_max.append(np.round(np.max(maxepoch)))
            nparams.append(npar)
            hh.append(h)
            ss.append(scale)
            rr.append(lr)
            dur.append(np.round((time.time() - start_time2)/60.0,2))
        output_data = {'H':hh,'params':nparams,'S':ss,'R':rr,
               'acc_train_mean':acc_train_mean,
               'acc_train_min':acc_train_min,'acc_train_max':acc_train_max,'acc_train_spread':acc_train_spread,
               'acc_test_mean':acc_test_mean,
               'acc_test_min':acc_test_min, 'acc_test_max':acc_test_max,'acc_test_spread':acc_test_spread,
               'minutes':dur,
               'epoch_mean':epoch_mean,'epoch_min':epoch_min,'epoch_max':epoch_max}
        df = pd.DataFrame(output_data)
        df = df[['H','params','S','R',
                 'acc_train_mean','acc_train_min','acc_train_max','acc_train_spread',
                 'acc_test_mean','acc_test_min','acc_test_max','acc_test_spread',
                 'minutes','epoch_mean','epoch_min','epoch_max']]
        experiment = ''
        if len(scales)==1: experiment += 's' + str(scale) + '_'
        if len(lrs)==1: experiment += 'r' + str(lr) + '_'
        experiment += 'e' + str(epochs) + '_b' + str(batch_size) + '_'
        experiment += '_'.join(activm)
        fileout = output_file + '_' + experiment
        print('fileout =',fileout)
        df.to_csv(fileout + '.csv', sep=',',index=False)
        print("Time: %s min" % np.round((time.time() - start_time)/60.0,2))
        sys.stdout.flush()
    return 


def cnn22_1d_cv(x,y,folds,f=[16,16],k=[7,7],h=[512,512],activc=['relu','relu'],activm=['relu','relu'],\
    pool=['max','max'],scale=1.0,lr=1e-4,epochs=100,batch_size=50,temp_dir='temp',seed=1000):
    # shape of x: [number of cases, number of features,number of channels]
    padding = 'same'
    nc = x.shape[1]
    nb = x.shape[2]
    nfolds = max(folds)
    accuracy_train = np.ones(nfolds)
    accuracy_test = np.ones(nfolds)
    maxepoch = np.ones(nfolds)
    for i in range(nfolds):
        test_sel = (folds == i+1)
        train_sel = ~(folds == i+1)
        x_train = x[train_sel,]
        y_train = y[train_sel,]
        x_test = x[test_sel,]
        y_test = y[test_sel,]
        np.random.seed(seed)
        idx = np.random.permutation(x_train.shape[0]) ## shuffle training data
        x_train = x_train[idx,]
        y_train = y_train[idx,]
        # data scaling
        x_train = scale * x_train
        x_test = scale * x_test
        ##print('Fold',i+1)
        K.clear_session()        
        tf.compat.v1.random.set_random_seed(seed)
        inp = Input(shape=(nc,nb),dtype = 'float32')
        conv1 = layers.Conv1D(f[0],k[0],activation = activc[0],input_shape = (nc,nb),padding = padding,\
		        kernel_initializer=my_init(activc[0],seed))(inp)
        if pool[0] == 'max':
            pool1 = layers.MaxPooling1D(2)(conv1)
        if pool[0] == 'avg':
            pool1 = layers.AveragePooling1D(2)(conv1)            
        conv2 = layers.Conv1D(f[1],k[1],activation = activc[1],padding = padding,\
                kernel_initializer=my_init(activc[1]))(pool1)
        if pool[1] == 'max':
            pool2 = layers.MaxPooling1D(2)(conv2)
        if pool[1] == 'avg':
            pool2 = layers.AveragePooling1D(2)(conv2)
        flat = layers.Flatten()(pool2)
        ##flat = layers.Dropout(0.5)(flat)
        fc1 = layers.Dense(h[0],activation = activm[0],kernel_initializer=my_init(activm[0]))(flat)
        ##fc1 = layers.Dropout(0.2)(fc1)
        fc2 = layers.Dense(h[1],activation = activm[1],kernel_initializer=my_init(activm[1]))(fc1)
        ##fc2 = layers.Dropout(0.2)(fc2)
        out = layers.Dense(2,activation = 'sigmoid',kernel_initializer=my_init('sigmoid'))(fc2)
        # early stopping
        callback_earlyStop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5)
        model = Model(inp,out)
        ##model.summary()
        model.compile(loss = 'categorical_crossentropy', optimizer = optimizers.Adam(learning_rate = lr), metrics = ['acc'])
        if not os.path.exists(temp_dir): os.makedirs(temp_dir)
        filepath = temp_dir + '/cnn_1d_'+str(i)+'.h5'
        if os.path.exists(filepath): os.remove(filepath)
        callbacks_list = [tf.keras.callbacks.ModelCheckpoint(filepath=filepath,monitor='val_loss',save_best_only=True), 
            tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=2),callback_earlyStop]
        history = model.fit(x_train,y_train,validation_split=0.2,epochs=epochs,
            batch_size=batch_size,callbacks=callbacks_list, verbose=0)
        ytrain_pred = model.predict([x_train])
        ytest_pred = model.predict([x_test])
        ytr_pred0 = ytrain_pred[:,0] > ytrain_pred[:,1]
        yte_pred0 = ytest_pred[:,0] > ytest_pred[:,1]
        accuracy_train[i] = 100*(1.0 - np.mean(ytr_pred0 == y_train[:,1]))
        accuracy_test[i] = 100*(1.0 - np.mean(yte_pred0 == y_test[:,1]))
        maxepoch[i] = len(history.history['acc'])
    nparams = model.count_params()
    return accuracy_train, accuracy_test, nparams, maxepoch, model, history


def cnn22_1d_cv_trial(output_file,x,y,folds,c1s,c2s,f1s,f2s,k1s,k2s,a1s,a2s,h1s,h2s,\
    scales=[1.0],lrs=[1e-4],epochs=100,batch_size=50,temp_dir='temp_cnn22_1d'):
    # function that compute cv results of mlp2 model
    activcs = [[c1,c2] for c1 in c1s for c2 in c2s if c1==c2]
    fs = [[f1,f2] for f1 in f1s for f2 in f2s if f1 >= f2]
    ks = [[k1,k2] for k1 in k1s for k2 in k2s if k1==k2]           
    activms = [[a1,a2] for a1 in a1s for a2 in a2s if a1==a2]
    hs = [[h1,h2] for h1 in h1s for h2 in h2s if h1 >= h2]
    activs = [[ac,am] for ac in activcs for am in activms]
    params = [[f,k,h,scale,lr] for f in fs for k in ks for h in hs for scale in scales for lr in lrs]
    for activ in activs: 
        activc = activ[0]
        activm = activ[1]
        start_time = time.time()
        print('activc:',activc,' activm:',activm)
        acc_train_mean = list()
        acc_train_min = list()
        acc_train_max = list()
        acc_train_spread = list()
        acc_test_mean = list()
        acc_test_min = list()
        acc_test_max = list()
        acc_test_spread = list()
        epoch_mean = list()
        epoch_min = list()
        epoch_max = list()
        nparams = list()
        ff = list()
        kk = list()            
        hh = list()
        ss = list()
        rr = list()
        dur = list()
        for par in params:
            start_time2 = time.time()
            f = par[0]
            k = par[1]
            h = par[2]
            scale = par[3]
            lr = par[4]
            print('f =',f,' k =',k,' h =',h,' s =',scale,' lr =',lr)
            sys.stdout.flush()
            accuracy_train,accuracy_test,npar,maxepoch,model,history = cnn22_1d_cv(x,y,folds,f=f,k=k,h=h,activc=activc,
                            activm=activm,scale=scale,lr=lr,epochs=epochs,batch_size=batch_size,temp_dir=temp_dir)
            acc_train_mean.append(np.round(np.mean(accuracy_train),2))
            acc_train_min.append(np.round(np.min(accuracy_train),2))
            acc_train_max.append(np.round(np.max(accuracy_train),2))
            acc_train_spread.append(np.round(spread(accuracy_train),2))
            acc_test_mean.append(np.round(np.mean(accuracy_test),2))
            acc_test_min.append(np.round(np.min(accuracy_test),2))
            acc_test_max.append(np.round(np.max(accuracy_test),2))
            acc_test_spread.append(np.round(spread(accuracy_test),2))
            epoch_mean.append(np.round(np.mean(maxepoch),2))
            epoch_min.append(np.round(np.min(maxepoch)))
            epoch_max.append(np.round(np.max(maxepoch)))
            nparams.append(npar)
            ff.append(f)
            kk.append(k)
            hh.append(h)
            ss.append(scale)
            rr.append(lr)
            dur.append(np.round((time.time() - start_time2)/60.0,2))
        output_data = {'F':ff,'K':kk,'H':hh,'params':nparams,'S':ss,'R':rr,
               'acc_train_mean':acc_train_mean,
               'acc_train_min':acc_train_min,'acc_train_max':acc_train_max,'acc_train_spread':acc_train_spread,
               'acc_test_mean':acc_test_mean,
               'acc_test_min':acc_test_min, 'acc_test_max':acc_test_max,'acc_test_spread':acc_test_spread,
               'minutes':dur,
               'epoch_mean':epoch_mean,'epoch_min':epoch_min,'epoch_max':epoch_max}
        df = pd.DataFrame(output_data)
        df = df[['F', 'K', 'H', 'params','S','R',
                     'acc_train_mean','acc_train_min','acc_train_max','acc_train_spread',
                     'acc_test_mean','acc_test_min','acc_test_max','acc_test_spread',
                     'minutes','epoch_mean','epoch_min','epoch_max']]
        experiment = ''
        if len(scales)==1: experiment += 's' + str(scale) + '_'
        if len(lrs)==1: experiment += 'r' + str(lr) + '_'
        experiment += 'e' + str(epochs) + '_b' + str(batch_size) + '_'
        experiment += '_'.join(activc) + '_' + '_'.join(activm)
        fileout = output_file + '_' + experiment
        print('fileout =',fileout)
        df.to_csv(fileout + '.csv', sep=',',index=False)
        print("Time: %s min" % np.round((time.time() - start_time)/60.0,2))
        sys.stdout.flush()
    return 

	

def mlp2_2d_cv(x,y,folds,h=[512,512],activm=['relu','relu'],scale=1.0,lr=1e-4,epochs=100,batch_size=50,temp_dir='temp',seed=1000):
    padding = 'same'
    nr = x.shape[1]
    nc = x.shape[2]
    nb = x.shape[3]
    nfolds = max(folds)
    accuracy_train = np.ones(nfolds)
    accuracy_test = np.ones(nfolds)
    maxepoch = np.ones(nfolds)
    for i in range(nfolds):
        test_sel = (folds == i+1)
        train_sel = ~(folds == i+1)
        x_train = x[train_sel,]
        y_train = y[train_sel,]
        x_test = x[test_sel,]
        y_test = y[test_sel,]
        np.random.seed(seed)
        idx = np.random.permutation(x_train.shape[0]) ## shuffle training data
        x_train = x_train[idx,]
        y_train = y_train[idx,]
        # data scaling
        x_train = scale * x_train
        x_test = scale * x_test
        ##print('Fold',i+1)
        K.clear_session()
        tf.compat.v1.random.set_random_seed(seed)
        inp = Input(shape=(nr,nc,nb),dtype = 'float32')
        flat = layers.Flatten()(inp)
        ##flat = layers.Dropout(0.5)(flat)
        fc1 = layers.Dense(h[0],activation = activm[0],kernel_initializer=my_init(activm[0],seed))(flat)
        ##fc1 = layers.Dropout(0.2)(fc1)
        fc2 = layers.Dense(h[1],activation = activm[1],kernel_initializer=my_init(activm[0]))(fc1)
        ##fc2 = layers.Dropout(0.2)(fc2)
        out = layers.Dense(2,activation = 'sigmoid',kernel_initializer=my_init('sigmoid'))(fc2)
        # early stopping
        callback_earlyStop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5)
        model = Model(inp,out)
        ##model.summary()
        model.compile(loss = 'categorical_crossentropy', optimizer = optimizers.Adam(learning_rate = lr), metrics = ['acc'])
        if not os.path.exists(temp_dir): os.makedirs(temp_dir)
        filepath = temp_dir+'/mlp_2d_'+str(i)+'.h5'
        if os.path.exists(filepath): os.remove(filepath)
        callbacks_list = [tf.keras.callbacks.ModelCheckpoint(filepath=filepath,monitor='val_loss',save_best_only=True), 
            tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=2),callback_earlyStop]
        history = model.fit(x_train,y_train,validation_split=0.2,epochs=epochs,
            batch_size=batch_size,callbacks=callbacks_list, verbose=0)
        ytrain_pred = model.predict([x_train])
        ytest_pred = model.predict([x_test])
        ytr_pred0 = ytrain_pred[:,0] > ytrain_pred[:,1]
        yte_pred0 = ytest_pred[:,0] > ytest_pred[:,1]
        accuracy_train[i] = 100*(1.0 - np.mean(ytr_pred0 == y_train[:,1]))
        accuracy_test[i] = 100*(1.0 - np.mean(yte_pred0 == y_test[:,1]))
        maxepoch[i] = len(history.history['acc'])
    nparams = model.count_params()
    return accuracy_train, accuracy_test, nparams, maxepoch, model, history

def mlp2_2d_cv_trial(output_file,x,y,folds,a1s,a2s,h1s,h2s,scales=[1.0],lrs=[1e-4],epochs=100,batch_size=50,temp_dir='temp_mlp'):
    # function that compute cv results of mlp2 model
    activms = [[a1,a2] for a1 in a1s for a2 in a2s if a1==a2]
    hs = [[h1,h2] for h1 in h1s for h2 in h2s if h1 >= h2]
    params = [[h,scale,lr] for h in hs for scale in scales for lr in lrs]
    for activm in activms:
        start_time = time.time()
        print('activm:',activm)
        acc_train_mean = list()
        acc_train_min = list()
        acc_train_max = list()
        acc_train_spread = list()
        acc_test_mean = list()
        acc_test_min = list()
        acc_test_max = list()
        acc_test_spread = list()
        epoch_mean = list()
        epoch_min = list()
        epoch_max = list()
        nparams = list()
        hh = list()
        ss = list()
        rr = list()
        dur = list()
        for par in params:
            start_time2 = time.time()
            h = par[0]
            scale = par[1]
            lr = par[2]
            print('h =',h,' scale =',scale,' lr = ',lr)
            sys.stdout.flush()
            accuracy_train,accuracy_test,npar,maxepoch,model,history = mlp2_2d_cv(x,y,folds,h=h,activm=activm,\
                       scale=scale,lr=lr,epochs=epochs,batch_size=batch_size,temp_dir=temp_dir)
            acc_train_mean.append(np.round(np.mean(accuracy_train),2))
            acc_train_min.append(np.round(np.min(accuracy_train),2))
            acc_train_max.append(np.round(np.max(accuracy_train),2))
            acc_train_spread.append(np.round(spread(accuracy_train),2))
            acc_test_mean.append(np.round(np.mean(accuracy_test),2))
            acc_test_min.append(np.round(np.min(accuracy_test),2))
            acc_test_max.append(np.round(np.max(accuracy_test),2))
            acc_test_spread.append(np.round(spread(accuracy_test),2))
            epoch_mean.append(np.round(np.mean(maxepoch),2))
            epoch_min.append(np.round(np.min(maxepoch)))
            epoch_max.append(np.round(np.max(maxepoch)))
            nparams.append(npar)
            hh.append(h)
            ss.append(scale)
            rr.append(lr)
            dur.append(np.round((time.time() - start_time2)/60.0,2))
        output_data = {'H':hh,'params':nparams,'S':ss,'R':rr,
               'acc_train_mean':acc_train_mean,
               'acc_train_min':acc_train_min,'acc_train_max':acc_train_max,'acc_train_spread':acc_train_spread,
               'acc_test_mean':acc_test_mean,
               'acc_test_min':acc_test_min, 'acc_test_max':acc_test_max,'acc_test_spread':acc_test_spread,
               'minutes':dur,
               'epoch_mean':epoch_mean,'epoch_min':epoch_min,'epoch_max':epoch_max}
        df = pd.DataFrame(output_data)
        df = df[['H','params','S','R',
                 'acc_train_mean','acc_train_min','acc_train_max','acc_train_spread',
                 'acc_test_mean','acc_test_min','acc_test_max','acc_test_spread',
                 'minutes','epoch_mean','epoch_min','epoch_max']]
        experiment = ''
        if len(scales)==1: experiment += 's' + str(scale) + '_'
        if len(lrs)==1: experiment += 'r' + str(lr) + '_'
        experiment += 'e' + str(epochs) + '_b' + str(batch_size) + '_'
        experiment += '_'.join(activm)
        fileout = output_file + '_' + experiment
        print('fileout =',fileout)
        df.to_csv(fileout + '.csv', sep=',',index=False)
        print("Time: %s min" % np.round((time.time() - start_time)/60.0,2))
        sys.stdout.flush()
    return 



def cnn22_2d_cv(x,y,folds,f=[16,16],k=[7,7],h=[512,512],activc=['relu','relu'],activm=['relu','relu'],\
    pool=['max','max'],scale=1.0,lr=1e-4,epochs=100,batch_size=50,temp_dir='temp',seed=1000):
    padding = 'same'
    nr = x.shape[1]
    nc = x.shape[2]
    nb = x.shape[3]
    nfolds = max(folds)
    accuracy_train = np.ones(nfolds)
    accuracy_test = np.ones(nfolds)
    maxepoch = np.ones(nfolds)
    for i in range(nfolds):
        test_sel = (folds == i+1)
        train_sel = ~(folds == i+1)
        x_train = x[train_sel,]
        y_train = y[train_sel,]
        x_test = x[test_sel,]
        y_test = y[test_sel,]
        np.random.seed(seed)
        idx = np.random.permutation(x_train.shape[0]) ## shuffle training data
        x_train = x_train[idx,]
        y_train = y_train[idx,]
        # data scaling
        x_train = scale * x_train
        x_test = scale * x_test
        ##print('Fold',i+1)
        K.clear_session()        
        tf.compat.v1.random.set_random_seed(seed)
        inp = Input(shape=(nr,nc,nb),dtype = 'float32')
        conv1 = layers.Conv2D(f[0],(k[0],k[0]),activation = activc[0],input_shape = (nr,nc,nb),padding = padding,\
                   kernel_initializer=my_init(activc[0],seed))(inp)
        if pool[0] == 'max':
            pool1 = layers.MaxPooling2D((2, 2))(conv1)
        if pool[0] == 'avg':
            pool1 = layers.AveragePooling2D((2, 2))(conv1)            
        conv2 = layers.Conv2D(f[1],(k[1],k[1]), activation = activc[1],padding = padding,\
                   kernel_initializer=my_init(activc[1]))(pool1)
        if pool[1] == 'max':
            pool2 = layers.MaxPooling2D((2, 2))(conv2)
        if pool[1] == 'avg':
            pool2 = layers.AveragePooling2D((2, 2))(conv2)
        flat = layers.Flatten()(pool2)
        ##flat = layers.Dropout(0.5)(flat)
        fc1 = layers.Dense(h[0],activation = activm[0],kernel_initializer=my_init(activm[0]))(flat)
        ##fc1 = layers.Dropout(0.2)(fc1)
        fc2 = layers.Dense(h[1],activation = activm[1],kernel_initializer=my_init(activm[1]))(fc1)
        ##fc2 = layers.Dropout(0.2)(fc2)
        out = layers.Dense(2,activation = 'sigmoid',kernel_initializer=my_init('sigmoid'))(fc2)
        # early stopping
        callback_earlyStop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5)
        model = Model(inp,out)
        ##model.summary()
        model.compile(loss = 'categorical_crossentropy', optimizer = optimizers.Adam(learning_rate = lr), metrics = ['acc'])
        if not os.path.exists(temp_dir): os.makedirs(temp_dir)
        filepath = temp_dir + '/cnn_2d_'+str(i)+'.h5'
        if os.path.exists(filepath): os.remove(filepath)
        callbacks_list = [tf.keras.callbacks.ModelCheckpoint(filepath=filepath,monitor='val_loss',save_best_only=True), 
            tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=2),callback_earlyStop]
        history = model.fit(x_train,y_train,validation_split=0.2,epochs=epochs,
            batch_size=batch_size,callbacks=callbacks_list, verbose=0)
        ytrain_pred = model.predict([x_train])
        ytest_pred = model.predict([x_test])
        ytr_pred0 = ytrain_pred[:,0] > ytrain_pred[:,1]
        yte_pred0 = ytest_pred[:,0] > ytest_pred[:,1]
        accuracy_train[i] = 100*(1.0 - np.mean(ytr_pred0 == y_train[:,1]))
        accuracy_test[i] = 100*(1.0 - np.mean(yte_pred0 == y_test[:,1]))
        maxepoch[i] = len(history.history['acc'])
    nparams = model.count_params()
    return accuracy_train, accuracy_test, nparams, maxepoch, model, history


def cnn22_2d_cv_trial(output_file,x,y,folds,c1s,c2s,f1s,f2s,k1s,k2s,a1s,a2s,h1s,h2s,\
    scales=[1.0],lrs=[1e-4],epochs=100,batch_size=50,temp_dir='temp_qper'):
    # function that compute cv results of mlp2 model
    activcs = [[c1,c2] for c1 in c1s for c2 in c2s if c1==c2]
    fs = [[f1,f2] for f1 in f1s for f2 in f2s if f1 >= f2]
    ks = [[k1,k2] for k1 in k1s for k2 in k2s if k1==k2]           
    activms = [[a1,a2] for a1 in a1s for a2 in a2s if a1==a2]
    hs = [[h1,h2] for h1 in h1s for h2 in h2s if h1 >= h2]
    activs = [[ac,am] for ac in activcs for am in activms]
    params = [[f,k,h,scale,lr] for f in fs for k in ks for h in hs for scale in scales for lr in lrs]
    for activ in activs: 
        activc = activ[0]
        activm = activ[1]
        start_time = time.time()
        print('activc:',activc,' activm:',activm)
        acc_train_mean = list()
        acc_train_min = list()
        acc_train_max = list()
        acc_train_spread = list()
        acc_test_mean = list()
        acc_test_min = list()
        acc_test_max = list()
        acc_test_spread = list()
        epoch_mean = list()
        epoch_min = list()
        epoch_max = list()
        nparams = list()
        ff = list()
        kk = list()            
        hh = list()
        ss = list()
        rr = list()
        dur = list()
        for par in params:
            start_time2 = time.time()
            f = par[0]
            k = par[1]
            h = par[2]
            scale = par[3]
            lr = par[4]
            print('f =',f,' k =',k,' h =',h,' s =',scale,' lr =',lr)
            sys.stdout.flush()
            accuracy_train,accuracy_test,npar,maxepoch,model,history = cnn22_2d_cv(x,y,folds,f=f,k=k,h=h,activc=activc,
                            activm=activm,scale=scale,lr=lr,epochs=epochs,batch_size=batch_size,temp_dir=temp_dir)
            acc_train_mean.append(np.round(np.mean(accuracy_train),2))
            acc_train_min.append(np.round(np.min(accuracy_train),2))
            acc_train_max.append(np.round(np.max(accuracy_train),2))
            acc_train_spread.append(np.round(spread(accuracy_train),2))
            acc_test_mean.append(np.round(np.mean(accuracy_test),2))
            acc_test_min.append(np.round(np.min(accuracy_test),2))
            acc_test_max.append(np.round(np.max(accuracy_test),2))
            acc_test_spread.append(np.round(spread(accuracy_test),2))
            epoch_mean.append(np.round(np.mean(maxepoch),2))
            epoch_min.append(np.round(np.min(maxepoch)))
            epoch_max.append(np.round(np.max(maxepoch)))
            nparams.append(npar)
            ff.append(f)
            kk.append(k)
            hh.append(h)
            ss.append(scale)
            rr.append(lr)
            dur.append(np.round((time.time() - start_time2)/60.0,2))
        output_data = {'F':ff,'K':kk,'H':hh,'params':nparams,'S':ss,'R':rr,
               'acc_train_mean':acc_train_mean,
               'acc_train_min':acc_train_min,'acc_train_max':acc_train_max,'acc_train_spread':acc_train_spread,
               'acc_test_mean':acc_test_mean,
               'acc_test_min':acc_test_min, 'acc_test_max':acc_test_max,'acc_test_spread':acc_test_spread,
               'minutes':dur,
               'epoch_mean':epoch_mean,'epoch_min':epoch_min,'epoch_max':epoch_max}
        df = pd.DataFrame(output_data)
        df = df[['F', 'K', 'H', 'params','S','R',
                     'acc_train_mean','acc_train_min','acc_train_max','acc_train_spread',
                     'acc_test_mean','acc_test_min','acc_test_max','acc_test_spread',
                     'minutes','epoch_mean','epoch_min','epoch_max']]
        experiment = ''
        if len(scales)==1: experiment += 's' + str(scale) + '_'
        if len(lrs)==1: experiment += 'r' + str(lr) + '_'
        experiment += 'e' + str(epochs) + '_b' + str(batch_size) + '_'
        experiment += '_'.join(activc) + '_' + '_'.join(activm)
        fileout = output_file + '_' + experiment
        print('fileout =',fileout)
        df.to_csv(fileout + '.csv', sep=',',index=False)
        print("Time: %s min" % np.round((time.time() - start_time)/60.0,2))
        sys.stdout.flush()
    return 


def cnn22_3d_cv(x,y,folds,f=[16,16],k=[7,7],h=[512,512],activc=['relu','relu'],activm=['relu','relu'],\
    pool=['max','max'],scale=1.0,lr=1e-4,epochs=100,batch_size=50,temp_dir='temp',seed=1000):
    padding = 'same'
    nr = x.shape[1]
    nc = x.shape[2]
    nt = x.shape[3]
    nb = x.shape[4]
    nfolds = max(folds)
    accuracy_train = np.ones(nfolds)
    accuracy_test = np.ones(nfolds)
    maxepoch = np.ones(nfolds)
    for i in range(nfolds):
        test_sel = (folds == i+1)
        train_sel = ~(folds == i+1)
        x_train = x[train_sel,]
        y_train = y[train_sel,]
        x_test = x[test_sel,]
        y_test = y[test_sel,]
        np.random.seed(seed)
        idx = np.random.permutation(x_train.shape[0]) ## shuffle training data
        x_train = x_train[idx,]
        y_train = y_train[idx,]
        # data scaling
        x_train = scale * x_train
        x_test = scale * x_test
        ##print('Fold',i+1)
        K.clear_session()        
        tf.compat.v1.random.set_random_seed(seed)
        inp = Input(shape=(nr,nc,nt,nb),dtype = 'float32')
        conv1 = layers.Conv3D(f[0],(k[0],k[0],k[0]),activation = activc[0],input_shape = (nr,nc,nt,nb),padding = padding,\
                   kernel_initializer=my_init(activc[0],seed))(inp)
        if pool[0] == 'max':
            pool1 = layers.MaxPooling3D((2, 2, 2))(conv1)
        if pool[0] == 'avg':
            pool1 = layers.AveragePooling3D((2, 2, 2))(conv1)            
        conv2 = layers.Conv3D(f[1],(k[1],k[1],k[1]), activation = activc[1],padding = padding,\
                   kernel_initializer=my_init(activc[1]))(pool1)
        if pool[1] == 'max':
            pool2 = layers.MaxPooling3D((2, 2, 2))(conv2)
        if pool[1] == 'avg':
            pool2 = layers.AveragePooling3D((2, 2, 2))(conv2)
        flat = layers.Flatten()(pool2)
        ##flat = layers.Dropout(0.5)(flat)
        fc1 = layers.Dense(h[0],activation = activm[0],kernel_initializer=my_init(activm[0]))(flat)
        ##fc1 = layers.Dropout(0.2)(fc1)
        fc2 = layers.Dense(h[1],activation = activm[1],kernel_initializer=my_init(activm[1]))(fc1)
        ##fc2 = layers.Dropout(0.2)(fc2)
        out = layers.Dense(2,activation = 'sigmoid',kernel_initializer=my_init('sigmoid'))(fc2)
        # early stopping
        callback_earlyStop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5)
        model = Model(inp,out)
        ##model.summary()
        model.compile(loss = 'categorical_crossentropy', optimizer = optimizers.Adam(learning_rate = lr), metrics = ['acc'])
        if not os.path.exists(temp_dir): os.makedirs(temp_dir)
        filepath = temp_dir + '/cnn_3d_'+str(i)+'.h5'
        if os.path.exists(filepath): os.remove(filepath)
        callbacks_list = [tf.keras.callbacks.ModelCheckpoint(filepath=filepath,monitor='val_loss',save_best_only=True), 
            tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=2),callback_earlyStop]
        history = model.fit(x_train,y_train,validation_split=0.2,epochs=epochs,
            batch_size=batch_size,callbacks=callbacks_list, verbose=0)
        ytrain_pred = model.predict([x_train])
        ytest_pred = model.predict([x_test])
        ytr_pred0 = ytrain_pred[:,0] > ytrain_pred[:,1]
        yte_pred0 = ytest_pred[:,0] > ytest_pred[:,1]
        accuracy_train[i] = 100*(1.0 - np.mean(ytr_pred0 == y_train[:,1]))
        accuracy_test[i] = 100*(1.0 - np.mean(yte_pred0 == y_test[:,1]))
        maxepoch[i] = len(history.history['acc'])
    nparams = model.count_params()
    return accuracy_train, accuracy_test, nparams, maxepoch, model, history


def cnn22_3d_cv_trial(output_file,x,y,folds,c1s,c2s,f1s,f2s,k1s,k2s,a1s,a2s,h1s,h2s,\
    scales=[1.0],lrs=[1e-4],epochs=100,batch_size=50,temp_dir='temp_qper'):
    # function that compute cv results of mlp2 model
    activcs = [[c1,c2] for c1 in c1s for c2 in c2s if c1==c2]
    fs = [[f1,f2] for f1 in f1s for f2 in f2s if f1 >= f2]
    ks = [[k1,k2] for k1 in k1s for k2 in k2s if k1==k2]           
    activms = [[a1,a2] for a1 in a1s for a2 in a2s if a1==a2]
    hs = [[h1,h2] for h1 in h1s for h2 in h2s if h1 >= h2]
    activs = [[ac,am] for ac in activcs for am in activms]
    params = [[f,k,h,scale,lr] for f in fs for k in ks for h in hs for scale in scales for lr in lrs]
    for activ in activs: 
        activc = activ[0]
        activm = activ[1]
        start_time = time.time()
        print('activc:',activc,' activm:',activm)
        acc_train_mean = list()
        acc_train_min = list()
        acc_train_max = list()
        acc_train_spread = list()
        acc_test_mean = list()
        acc_test_min = list()
        acc_test_max = list()
        acc_test_spread = list()
        epoch_mean = list()
        epoch_min = list()
        epoch_max = list()
        nparams = list()
        ff = list()
        kk = list()            
        hh = list()
        ss = list()
        rr = list()
        dur = list()
        for par in params:
            start_time2 = time.time()
            f = par[0]
            k = par[1]
            h = par[2]
            scale = par[3]
            lr = par[4]
            print('f =',f,' k =',k,' h =',h,' s =',scale,' lr =',lr)
            sys.stdout.flush()
            accuracy_train,accuracy_test,npar,maxepoch,model,history = cnn22_3d_cv(x,y,folds,f=f,k=k,h=h,activc=activc,
                            activm=activm,scale=scale,lr=lr,epochs=epochs,batch_size=batch_size,temp_dir=temp_dir)
            acc_train_mean.append(np.round(np.mean(accuracy_train),2))
            acc_train_min.append(np.round(np.min(accuracy_train),2))
            acc_train_max.append(np.round(np.max(accuracy_train),2))
            acc_train_spread.append(np.round(spread(accuracy_train),2))
            acc_test_mean.append(np.round(np.mean(accuracy_test),2))
            acc_test_min.append(np.round(np.min(accuracy_test),2))
            acc_test_max.append(np.round(np.max(accuracy_test),2))
            acc_test_spread.append(np.round(spread(accuracy_test),2))
            epoch_mean.append(np.round(np.mean(maxepoch),2))
            epoch_min.append(np.round(np.min(maxepoch)))
            epoch_max.append(np.round(np.max(maxepoch)))
            nparams.append(npar)
            ff.append(f)
            kk.append(k)
            hh.append(h)
            ss.append(scale)
            rr.append(lr)
            dur.append(np.round((time.time() - start_time2)/60.0,2))
        output_data = {'F':ff,'K':kk,'H':hh,'params':nparams,'S':ss,'R':rr,
               'acc_train_mean':acc_train_mean,
               'acc_train_min':acc_train_min,'acc_train_max':acc_train_max,'acc_train_spread':acc_train_spread,
               'acc_test_mean':acc_test_mean,
               'acc_test_min':acc_test_min, 'acc_test_max':acc_test_max,'acc_test_spread':acc_test_spread,
               'minutes':dur,
               'epoch_mean':epoch_mean,'epoch_min':epoch_min,'epoch_max':epoch_max}
        df = pd.DataFrame(output_data)
        df = df[['F', 'K', 'H', 'params','S','R',
                     'acc_train_mean','acc_train_min','acc_train_max','acc_train_spread',
                     'acc_test_mean','acc_test_min','acc_test_max','acc_test_spread',
                     'minutes','epoch_mean','epoch_min','epoch_max']]
        experiment = ''
        if len(scales)==1: experiment += 's' + str(scale) + '_'
        if len(lrs)==1: experiment += 'r' + str(lr) + '_'
        experiment += 'e' + str(epochs) + '_b' + str(batch_size) + '_'
        experiment += '_'.join(activc) + '_' + '_'.join(activm)
        fileout = output_file + '_' + experiment
        print('fileout =',fileout)
        df.to_csv(fileout + '.csv', sep=',',index=False)
        print("Time: %s min" % np.round((time.time() - start_time)/60.0,2))
        sys.stdout.flush()
    return 
