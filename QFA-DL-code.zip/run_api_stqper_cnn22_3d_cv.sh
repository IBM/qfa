
#Specify input data directory
DataFolder="data"

#Specify name of data file (.csv)
DataFile='bond_disbond_stqfa_for_cnn_15x45x29'

#Specify number of moving windows
Windows=29

#Specify number of quantiles
Quantiles=45

#Specify output directory
OutputFolder="output_stqfa"

# Temporary directory
TempPath='/temp/temp_stqper_3d'

#Specify Convolution activation function layer 1 (e.g. Activation1C="relu,linear")
Activation1C="linear"

#Specify Convolution activation function layer 2
Activation2C=${Activation1C}

#Specify feature maps in convolution layer 1
FeatureMap1="256,128,64,32"

#Specify feature maps in convolution layer 2
FeatureMap2=${FeatureMap1}

#Specify filter size in convolution layer 1
FilterSize1="5"

#Specify filter size in convolution layer 2
FilterSize2=${FilterSize1}

#Specify MLP activation function layer 1 (e.g. Activation1="relu,tanh")
Activation1="relu"

#Specify MLP activation function layer 2
Activation2=${Activation1}

#Specify number of hidden nodes in MLP layer 1
HiddenNodes1="4096,2048,1024,512"

#Specify number of hidden nodes in MLP layer 2
HiddenNodes2=${HiddenNodes1}

# Scale of normalization
Scale="1.0"

# Learning Rate
Rate="0.0001"

# Number of epochs
Epoch=500

# Batch size
Batch=50


Py=$(which python)

echo "###########################################################################"
echo "CNN22-3D for Classification of Short-Time Quantile Periodograms"
echo "Input Data Folder: ${DataFolder}"
echo "Input Data File: ${DataFile}"
echo "Number of Moving Windows: ${Windows}"
echo "Number of Quantiles: ${Quantiles}"
echo "Output Folder: ${OutputFolder}"
echo "Convolution Activation 1: ${Activation1C}"
echo "Convolution Activation 2: ${Activation2C}"
echo "Number of Feature Maps 1: ${FeatureMap1}"
echo "Number of Feature Maps 2: ${FeatureMap2}"
echo "Size of Filter 1: ${FilterSize1}"
echo "Size of Filter 2: ${FilterSize2}"
echo "MLP Activation 1: ${Activation1}"
echo "MLP Activation 2: ${Activation2}"
echo "Number of MLP Hidden Nodes 1: ${HiddenNodes1}"
echo "Number of MLP Hidden Nodes 2: ${HiddenNodes2}"
echo "Scale: ${Scale}"
echo "Learning Rate: ${Rate}"
echo "Number of Epochs: ${Epoch}"
echo "Batch Size: ${Batch}"
echo "Using Python at: ${Py}"
echo "###########################################################################"


time python src/analytics/api_stqper_cnn22_3d_cv.py $DataFolder $DataFile $Windows $Quantiles $OutputFolder ${Activation1C} ${Activation2C} ${FeatureMap1} ${FeatureMap2} ${FilterSize1} ${FilterSize2} ${Activation1} ${Activation2} ${HiddenNodes1} ${HiddenNodes2} $Scale $Rate $Epoch $Batch $TempPath


