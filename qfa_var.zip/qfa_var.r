
dir.r<-"c:/Home/thl/Res/cm/"
dir.s<-paste(dir.r,"splus/",sep="")
dir.d<-paste(dir.r,"data/",sep="")
dir.p<-paste(dir.r,"ps/",sep="")
library("quantreg")
library("fields")
library("colorRamps")

source(paste(dir.s,"qfa.lib",sep=""))

mycolors<-c("#AACCEE","red1","#029F00","#0140CA","mediumorchid1","#009fff","#FFBF00","gray75",
"palegreen3","mediumpurple1","lightslateblue","lightsalmon")

color.grey<-rev(colorRampPalette(c("black", "white"))(64))

color.qper<-topo.colors(1024)
color2.qper<-rev(color.qper)
color.cqper<-rainbow(1024)
color.qper<-matlab.like2(1024)


file<-"financial_index"
x0<-read.csv(paste(dir.r,"data/",file,".csv",sep=""),header=T)



# indexed by calendar days
day0<-rev(as.character(x0[,1]))
day0<-as.Date(paste(substr(day0,1,4),substr(day0,5,6),substr(day0,7,8),sep="-"))
day<-seq(min(day0),max(day0),1)
n<-length(day)

sel.d<-match(day0,day)
x1<-rep(NA,n)
x2<-x1
x1[sel.d]<-rev(x0[,2]); lab1<-"DJIA" 
x2[sel.d]<-rev(x0[,3]); lab2<-"FTSE"  


par(mfrow=c(2,1),pty="m",mar=c(5,4,2,1)+0.1,lab=c(10,7,7),las=1)
plot(day,x1/1000,type='l',main=lab1,xlab="Calendar Day",ylab="Closing Value (K)")
plot(day,x2/1000,type='l',main=lab2,xlab="Calendar Day",ylab="Closing Value (K)")




# -- Analysis by Trading Days
option<-"TD"

# plot time series by trading days
par(mfrow=c(2,1),pty="m",mar=c(5,4,2,1)+0.1,lab=c(10,7,7),las=1)
plot(day0,x1[sel.d]/1000,type='l',main=lab1,xlab="Trading Day",ylab="Closing Value (K)")
plot(day0,x2[sel.d]/1000,type='l',main=lab2,xlab="Trading Day",ylab="Closing Value (K)")

# compute log returns by trading days
y1<-diff(log(x1[sel.d]))
y2<-diff(log(x2[sel.d]))

# plot log retern series by trading days
par(mfrow=c(2,1),pty="m",mar=c(5,4,2,1)+0.1,lab=c(10,7,7),las=1)
plot(day0[-1],y1,type='l',ylab="Log Return",main=lab1,xlab="Trading Day",ylim=c(-0.1,0.1))
plot(day0[-1],y2,type='l',ylab="Log Return",main=lab2,xlab="Trading Day",ylim=c(-0.1,0.1))


# specify time window of analysis
##day1<-day0[1]
##dayn<-day0[length(day0)]
day1<-as.Date("2004-01-01")
dayn<-as.Date("2007-08-01")-1
twlab<-paste(day1,'~',dayn); twlab


# extract log return data in time window
sel0<-which(day0[-1] >= day1 & day0[-1] <= dayn)
yy1<-y1[sel0]
yy2<-y2[sel0]
nn<-length(sel0)
y<-cbind(yy1,yy2)
lab<-c(lab1,lab2)
rg<-c(-max(abs(y)),max(abs(y)))

# plot log retern series in time window
par(mfrow=c(2,1),pty="m",mar=c(5,4,2,1)+0.1,lab=c(10,7,7),las=1)
plot(y[,1],type='l',ylab="Log Return",main=paste0(lab[1],": ",twlab),xlab="Index",ylim=rg)
abline(h=0,lty=2)
plot(y[,2],type='l',ylab="Log Return",main=paste0(lab[2],": ",twlab),xlab="Index",ylim=rg)
abline(h=0,lty=2)


# -- coherence analysis of financial index ---



# Fourier frequencies
ff<-c(0:(nn-1))/nn 
nf<-length(ff)
sel.f <- which(ff < 0.5 & ff > 0)

tau.min <- 0.04
tau.max <- 0.96
tau.del<- 0.02
tau<-seq(tau.min,tau.max,tau.del); tau
ntau<-length(tau)


n.cores <- 6

if(n.cores>1) {
  library(foreach) 
  library(doParallel) # libraries required for parallel computing
  cl <- makeCluster(n.cores)
  clusterExport(cl, c("rq"))
  registerDoParallel(cl) 
}

qcper<-lap.cspec(y,ff,tau,intercept=T,n.cores=n.cores,exist.cores=T)


if(n.cores>1) stopCluster(cl)




k<-1
kk<-2
qper <- Re(qcper[k,k,sel.f,])
tlab<-paste0("Quantile Periodogam\n",lab[k],": ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)

qper <- Re(qcper[kk,kk,sel.f,])
tlab<-paste0("Quantile Periodogam\n",lab[kk],": ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)



qper <- Mod(qcper[k,kk,sel.f,])
tlab<-paste0("Amplitude of Quantile Cross-Periodogam\n","(",lab[k],",", lab[kk],"): ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)

qper <- Arg(qcper[k,kk,sel.f,])
tlab<-paste0("Phase of Quantile Cross-Periodogam\n","(",lab[k],",", lab[kk],"): ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)

qper <- Re(qcper[k,kk,sel.f,])
tlab<-paste0("Quantile Co-Periodogam\n","(",lab[k],",", lab[kk],"): ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)

qper <- Im(qcper[k,kk,sel.f,])
tlab<-paste0("Quantile Quadrature-Periodogam\n","(",lab[k],",", lab[kk],"): ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)


# coherence by spline smoothing
coh <- matrix(NA,nf,ntau)
sper1 <- coh
sper2 <- coh
scper <- coh
for(i in c(1:ntau)) {
  per1<-Re(qcper[k,k,,i])
  per2<-Re(qcper[kk,kk,,i])
  cper<-qcper[k,kk,,i]
  tmp<-coh.smooth(per1,per2,cper,ff,smth="spline",df=sqrt(length(per1)))
  coh[,i] <- tmp$coh
  sper1[,i] <- tmp$sper1
  sper2[,i] <- tmp$sper2
  scper[,i] <- tmp$scper
}

qper <- Mod(coh[sel.f,])^2
tlab<-paste0("Quantile Coherence\n","(",lab[k],",", lab[kk],"): ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)


qper <- Arg(coh[sel.f,])
tlab<-paste0("Phase Quantile Coherence\n","(",lab[k],",", lab[kk],"): ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)

qper <- sper1[sel.f,]
tlab<-paste0("Smoothed Quantile Periodogram\n",lab[k],": ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)


qper <- sper2[sel.f,]
tlab<-paste0("Smoothed Quantile Periodogram\n",lab[kk],": ",twlab)
qfa.plot(ff[sel.f],tau,qper,rg.qper=range(qper),rg.tau=range(tau),color=color.qper,tlab=tlab)


# quantile autovariance function
qacf<-qcper.ar.fit(qcper,ff)$qacf



# plot quantile autovariance functions
j<-1
##j<-ntau
##j<-24
lags<-c(0:(nn-1))
sel.l<-which(lags < 60)
rg<-range(qacf[1,2,sel.l,j],qacf[2,1,sel.l,j])
lty<-"h"
par(mfrow=c(2,2),pty="m",mar=c(4,4,3,1)+0.1,lab=c(10,7,7),las=1,cex=0.5)
plot(lags[sel.l],qacf[1,1,sel.l,j],type=lty,ylab=NA,xlab="Lag",main=paste0("Quantile Autocovariance Function\n",lab[1],": ", twlab))
legend(x="topright",legend=paste0("ALPHA=",tau[j]),bty="n")
plot(lags[sel.l],qacf[1,2,sel.l,j],type=lty,ylab=NA,xlab="Lag",main=paste0("Quantile Cross-Autocovariance Function\n","(",lab[1],",",lab[2],"): ", twlab),ylim=rg)
legend(x="topright",legend=paste0("ALPHA=",tau[j]),bty="n")
plot(lags[sel.l],qacf[2,1,sel.l,j],type=lty,ylab=NA,xlab="Lag",main=paste0("Quantile Cross-Autocovariance Function\n","(",lab[2],",",lab[1],"): ", twlab),ylim=rg)
legend(x="topright",legend=paste0("ALPHA=",tau[j]),bty="n")
plot(lags[sel.l],qacf[2,2,sel.l,j],type=lty,ylab=NA,xlab="Lag",main=paste0("Quantile Autocovariance Function\n",lab[2],": ", twlab))
legend(x="topright",legend=paste0("ALPHA=",tau[j]),bty="n")



# plot quantile autocorrelation functions
j<-1
##j<-ntau
##j<-24
lags<-c(0:(nn-1))
sel.l<-which(lags < 60)
rg<-range(qacf[1,2,sel.l,j],qacf[2,1,sel.l,j])/sqrt(qacf[1,1,1,j]*qacf[2,2,1,j])
lty<-"h"
par(mfrow=c(2,2),pty="m",mar=c(4,4,3,1)+0.1,lab=c(10,7,7),las=1,cex=0.5)
plot(lags[sel.l],qacf[1,1,sel.l,j]/qacf[1,1,1,j],type=lty,ylab=NA,xlab="Lag",main=paste0("Quantile Autocorrelation Function\n",lab[1],": ", twlab))
legend(x="topright",legend=paste0("ALPHA=",tau[j]),bty="n"); abline(h=c(-1.96,1.96)/sqrt(nn),lty=2)
plot(lags[sel.l],qacf[1,2,sel.l,j]/sqrt(qacf[1,1,1,j]*qacf[2,2,1,j]),type=lty,ylab=NA,xlab="Lag",main=paste0("Quantile Cross-Autocorrelation Function\n","(",lab[1],",",lab[2],"): ", twlab),ylim=rg)
legend(x="topright",legend=paste0("ALPHA=",tau[j]),bty="n"); abline(h=c(-1.96,1.96)/sqrt(nn),lty=2)
plot(lags[sel.l],qacf[2,1,sel.l,j]/sqrt(qacf[1,1,1,j]*qacf[2,2,1,j]),type=lty,ylab=NA,xlab="Lag",main=paste0("Quantile Cross-Autocorrelation Function\n","(",lab[2],",",lab[1],"): ", twlab),ylim=rg)
legend(x="topright",legend=paste0("ALPHA=",tau[j]),bty="n"); abline(h=c(-1.96,1.96)/sqrt(nn),lty=2)
plot(lags[sel.l],qacf[2,2,sel.l,j]/qacf[2,2,1,j],type=lty,ylab=NA,xlab="Lag",main=paste0("Quantile Autocorrelation Function\n",lab[2],": ", twlab)); abline(h=c(-1.96,1.96)/sqrt(nn),lty=2)
legend(x="topright",legend=paste0("ALPHA=",tau[j]),bty="n"); abline(h=c(-1.96,1.96)/sqrt(nn),lty=2)




qcper.ar.fit<-function(qcper,freq,
  ord=NULL,aic=T,aic.form=c("aic","bic","aicc","arfit"),eps=0.005,
  pacf.smooth=F,pacf.smooth.method=c('supsmu','smooth.spline'),pacf.bass=0,pacf.df=NULL,pacf.cv=F,
  scale.smooth=F,scale.smooth.method=c('supsmu','smooth.spline'),scale.bass=0,scale.df=NULL,scale.cv=F,n.cores=1) {
  # y = ns*nc matrix: nc time series of length ns each
  # qcper = nc*nc*ns*ntau array: nc*nc matrix of quantile periodograms & cross-periodograms
  #         It must be calculated at ALL Fourier frequencies!
  # freq = frequencies at which the fitted VAR spectra are evaluated

  nc <- dim(qcper)[1]
  ns <- dim(qcper)[3]
  ntau <- dim(qcper)[4]
  ff <- c(0:(ns-1))/ns
  
    # (a) contruct the complete periodogram array by inserting 0 at zero-freqeuency
    ##qcperl <- array(0,dim=c(nc,nc,ns,ntau))
    ##for(k in c(1:nc)) {
    ##  qcperl[k,k,2:ns,] = apply(Re(qcper[k,k,,]),2,spec.padding,eps=eps)
    ##  if(k < nc) {	
    ##    for(kk in c((k+1):nc)) {
    ##      qcperl[k,kk,2:ns,] = qcper[k,kk,,]
    ##      qcperl[kk,k,2:ns,] = qcper[kk,k,,]
    ##    }
  	##  }
    ##}

    # (b) compute QACF from QCPER by FFT
    ##qacf <- qcper1
    qacf <- Re(qcper)
    for(k in c(1:nc)) {
      tmp <- matrix(qcperl[k,k,,],ncol=ntau)
      tmp <- apply(tmp,2,fft,inverse=T)/ns  
      qacf[k,k,,] <- Re(tmp)
      for(kk in c(1:nc)) {
        if(kk != k) {
          tmp <- matrix(qcperl[k,kk,,],ncol=ntau)
          tmp <- apply(tmp,2,fft,inverse=T)/ns
          qacf[k,kk,,] <- Re(tmp)
        }
      }
    }
    
	##plot(ff,qacf[1,1,,1],type='l')
  
    # (c) compute VAR Parameters from QACF by Levison-Durbin alg & order selection criteria
  
  
    # (e) select the best order of VAR model and compute the spectral array
  
    out<-list(qacf=qacf)
    out
}  

